def lambda_handler(event,context):
    print("Testing Lambda function")